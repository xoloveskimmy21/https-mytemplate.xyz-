# SCHOOL OF ENGINEERING
## itelective3-web

### AteneodeDavaoUniversity- School of Engineering and Architecture (SEA)

#### ![294080708_542060584374747_5401035328925890890_n](https://user-images.githubusercontent.com/110330192/185542946-5a933cbb-ef16-4550-80e9-e21e58dc4bc4.jpg)

##### This project aims to illustrate and determine the Stock Inventory System of Ateneo de Davao University - School of Engineering and Architecture

## Frameworks With Associated Logos

![example5](https://user-images.githubusercontent.com/110330192/185543191-94cb2fd6-47ca-4854-8194-9d01b58e30ed.png)

### Stock Inventory System

#### To demonstrate how much stock you have on hand at any given time and how you keep track of it, employ stock control, also referred to as inventory control. It holds true for all components, from raw materials to finished goods, that you use to create a good or service.

### PossibleSubsystems

##### - PaymentForStock
##### - ProvideStockOrShipment
##### - QualityControlOfStock
##### - DistributeOrSellStock
